quickstart build.xml requires
build_includes.xml located in 
uportal/bootstrap/build_includes.xml.
Had to change build.xml from 
      <import file="${uportal.dir}/bootstrap/build_includes.xml" />
to
    <import file="../../bootstrap/build_includes.xml" />

to locate properly